#!/bin/bash
# Script to check disk usage and send alert

THRESHOLD=80
DISK_USAGE=$(df / | grep / | awk '{print $5}' | sed 's/%//')

if [ $DISK_USAGE -gt $THRESHOLD ]; then
  echo "Disk usage is above $THRESHOLD%. Current usage is $DISK_USAGE%." | mail -s "Disk Usage Alert" admin@example.com
fi
