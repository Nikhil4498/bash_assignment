#!/bin/bash
# Script to create a directory structure in /home/user/

mkdir -p /home/user/projects/project1 /home/user/projects/project2 /home/user/projects/project3 /home/user/documents /home/user/downloads

echo "Directory structure created in /home/user/"
