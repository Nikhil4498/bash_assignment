#!/bin/bash
# Script to backup .txt files

if [ -z "$1" ]; then
  echo "Please provide a directory."
  exit 1
fi

timestamp=$(date +"%Y%m%d_%H%M%S")
backup_dir="backup_$timestamp"
mkdir $backup_dir

find "$1" -type f -name "*.txt" -exec cp {} "$backup_dir" \;

echo "Backup of .txt files created in $backup_dir."
