#!/bin/bash
# Script for text file analysis

if [ -z "$1" ]; then
  echo "Please provide a text file."
  exit 1
fi

echo "Lines: $(wc -l < $1)"
echo "Words: $(wc -w < $1)"
echo "Characters: $(wc -m < $1)"
