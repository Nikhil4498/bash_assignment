#!/bin/bash
# Script to generate system information report

echo "System Uptime: $(uptime)" > system_report.txt
echo "Memory Usage:" >> system_report.txt
free -h >> system_report.txt
echo "CPU Load: $(uptime | awk '{print $9}')" >> system_report.txt
echo "Disk Usage:" >> system_report.txt
df -h >> system_report.txt
echo "Running Processes:" >> system_report.txt
ps aux >> system_report.txt

echo "System report generated in system_report.txt."
