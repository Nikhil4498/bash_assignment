#!/bin/bash
# Script to monitor and start apache2 if not running

if ! pgrep apache2 > /dev/null; then
  systemctl start apache2
  echo "$(date): apache2 was not running and was started." >> /var/log/process_monitor.log
else
  echo "apache2 is running."
fi
