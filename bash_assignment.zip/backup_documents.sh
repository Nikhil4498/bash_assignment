#!/bin/bash
# Script to backup documents directory

tar -czf /home/user/backup/documents_backup.tar.gz /home/user/documents
