#!/bin/bash
# Script to check file permissions

if [ -r "$1" ]; then
    echo "The file $1 has read permission."
else
    echo "The file $1 does not have read permission."
fi

if [ -w "$1" ]; then
    echo "The file $1 has write permission."
else
    echo "The file $1 does not have write permission."
fi

if [ -x "$1" ]; then
    echo "The file $1 has execute permission."
else
    echo "The file $1 does not have execute permission."
fi
